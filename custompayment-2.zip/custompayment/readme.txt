=== Tutor Custom Payment ===
Contributors: Themeum
Requires at least: 4.5
Tested up to: 6.6.2
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html